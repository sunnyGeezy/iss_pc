Karma Switcher - Windows / Renderer v2

Open Insert -> Karma. Choose True Hero or Infamous, then close the overlay.
The game changes to maximum Good or Evil karma (Level 5) during gameplay.
Eligible upgrades for power types already earned are granted for that branch.
The chosen mode keeps karma at maximum for the session. Normal autosaves may
record karma and granted upgrades. No restart is needed to change modes.

Installation (matching HayatoG cde38af-based Windows launcher):
1. Close the game and launcher.
2. Back up out/tlg-probe-v2.exe in your existing launcher folder.
3. Extract this ZIP into that folder, allowing out/tlg-probe-v2.exe to be replaced.
4. Start the launcher and use any Renderer v2 preset. All share this executable.

Existing cursor, FPS menu and combined camera fixes are retained.
CUSA00223 update 1.07 and exact code signatures are checked. The switcher is
disabled when those checks fail. It uses normal game functions rather than
patching guessed save offsets or enabling both incompatible branches at once.

A byte-verified backup is created before each button request under
<data folder>/karma-backups/<timestamp>-<mode>. Only complete backups have
KARMA_BACKUP_VERIFIED.txt. A failed backup cancels the switch.
Story powers are not granted ahead of their normal unlocks. Story completion,
mission and collectible fields are not directly edited.

Tested: both overlay modes in gameplay; live scores +/-4300, correct side and
rank 5; no switch errors; verified backups; original test-source saves unchanged.
Native tests cover branch selection, repeated switches, signature guards,
backup failures and bridge register preservation. Specific Video summon behavior,
save/reload and extended-play progress checks remain unverified.

This package contains no game files or saves. Linux binary is not included.
